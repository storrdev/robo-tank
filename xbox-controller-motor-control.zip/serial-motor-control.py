import time
import math
import serial
import xbone

# Connect with the arduino nano via usb so we can read/send commands
ser = serial.Serial('/dev/ttyUSB0', baudrate = 9600, timeout = 1)

# Sleep for 3 seconds to let the arduino boot up before attempting to connect
time.sleep(3)

# Set flag for the arduino being ready so we can use it later to check before
# attempting to communicate with the arduino over serial
arduinoReady = False

# Initialize motor variables
leftSpeed = 0
leftDirection = True

rightSpeed = 0
rightDirection = True

# Function sendCommand
# 
# This function takes an array of data and structures it to be read by
# the arduino. It converts everything to bytes to be as efficient as possible
# because the arduino can only read one byte at a time on the other end
def sendCommand(command):
    byteCommand = bytes('<', 'utf-8') + bytes(command) + bytes('>', 'utf-8')

    # Sends converted command to arduino via serial communication over usb
    # and returns the amount of sent bytes
    return ser.write(byteCommand)

# Wait for command from arduino to let us know that it's connected
# via serial and ready to recieve commands
while not (arduinoReady):
    ready = ser.readline()

    if ready.decode() == '<Arduino is ready>\r\n':
        print(ready.decode().strip('\r\n'))
        arduinoReady = True

# This function is a loop that is passed to our XboxController instance
# so we can handle the commands coming from the Xbox controller
def inputLoop(state):
    # print(state)
    leftJoyY = round((state['leftJoy']['y'] / 128) - 256)

    leftSpeed = abs(leftJoyY) - 1

    # The motor doesn't really turn until after the analog pin driving it
    # hits around 120 (of 255) so we just ignore any input from the
    # Xbox controller that is less than 120
    if (leftSpeed < 120):
        leftSpeed = 0

    if leftJoyY > 0:
        leftDirection = True
    else:
        leftDirection = False

    rightSpeed = leftSpeed
    rightDirection = leftDirection

    print(leftSpeed)

    # Send Xbox controller commands to arduino
    sendCommand([leftSpeed, leftDirection, rightSpeed, rightDirection])
    
# Create an instance for the Xbox controller
xboxController = xbone.XboxOneController('/dev/input/event13', inputLoop)